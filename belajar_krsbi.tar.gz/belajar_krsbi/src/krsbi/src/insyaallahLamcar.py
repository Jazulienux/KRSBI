import cv2
import numpy as np

cam = cv2.VideoCapture(0)

if cam.isOpened():
	ret, frame = cam.read()

else:
	ret = False


while ret:

	ret,frame = cam.read()

	grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	edges = cv2.Canny(grey,50,250,apertureSize = 5, L2gradient=True)

	lines = cv2.HoughLines(edges,1,np.pi/180,200)

	if lines is not None:
		for rho,theta in lines[0]:
			a = np.cos(theta)
			b = np.sin(theta)
			x0 = a * rho
			y0 = b * rho
			pts1 = (int(x0+1000*(-b)),int(y0+1000*(-a)))
			pts2 = (int(x0-1000*(-b)),int(y0-1000*(-a)))
			cv2.line(frame,pts1,pts2,(255,255,255),3)

	cv2.imshow("Frame",frame)
	cv2.imshow("Edges",edges)

	if cv2.waitKey(1) == 27:
		break

cv2.destroyAllWindows()
cam.release()