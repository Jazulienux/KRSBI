import wx,os, time, thread

class Frame(wx.Frame):
    def __init__(self, parent, id, title):
        wx.Frame.__init__(self, parent, id, title, size=(100, 100),style=wx.MINIMIZE_BOX | wx.SYSTEM_MENU | wx.CAPTION | wx.CLOSE_BOX | wx.CLIP_CHILDREN)
        
        host=os.system('hostname')
        if host!='superman':

            #create the new thread
            thread.start_new_thread(self.not_superman, ())
            #sleep in the current one for 2 seconds
            time.sleep(1)

            self.Destroy()
        else:
            self.Center()
            self.Show()

    def not_superman(self):
            self.dialogBox=wx.MessageBox('The host name should be superman. Closing this dialog box in 2s...','Info')
            
if __name__ == '__main__':
    app = wx.App(redirect=False)
    frame = Frame(None, -1, 'Sample')
    app.MainLoop()
