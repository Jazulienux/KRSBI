#!/usr/bin/env python

import rospy
from std_msgs.msg import String
import sys

from Tkinter import *
import socket
import tkMessageBox


def callbackButton():
	try:
		getIp = setIpIsi.get()
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.connect((getIp, 28097))
		sta = True
		ket = ""

	except:
		sta = False

	while sta == True:
		try:
			RecData = str(s.recv(1024))
			
			if RecData == "W":
				ket = RecData + " ==> Cyan / Magenta Team"
			elif RecData == "s":
				ket = RecData + " ==> Cyan / Magenta Start"
			elif RecData == "S":
				ket = RecData + " ==> Cyan / Magenta Stop"
			elif RecData == "L":
				ket = RecData + " ==> Cyan / Magenta Park"
			elif RecData == "N":
				ket = RecData + " ==> Cyan / Magenta DropBall"
			elif RecData == "h":
				ket = RecData + " ==> Cyan / Magenta HT"
				# RecData = None
			elif RecData == "e":
				ket = RecData + " ==> Cyan / Magenta EndPart"
				# RecData = None
			elif RecData == "Z":
				ket = RecData + " ==> Reset Game"
				RecData = None


			elif RecData == "K":
				ket = RecData + " ==> Cyan KickOff"
			elif RecData == "F":
				ket = RecData + " ==> Cyan FreeCick"
			elif RecData == "G":
				ket = RecData + " ==> Cyan GoalKick"
			elif RecData == "T":
				ket = RecData + " ==> Cyan ThrowIn"
			elif RecData == "C":
				ket = RecData + " ==> Cyan CornerKick"
			elif RecData == "P":
				ket = RecData + " ==> Cyan PenaltyKick"
			elif RecData == "O":
				ket = RecData + " ==> Cyan Repair"
			elif RecData == "A":
				ket = RecData + " ==> Cyan Goal"
			elif(RecData=="Y"):
				ket = RecData + " ==> Cyan YellowCard"
			elif(RecData=="R"):
				ket = RecData + " ==> Cyan RedCard"


			elif(RecData=="1"):
				ket = RecData + " ==> 1 St"
			elif(RecData=="2"):
				ket = RecData + " ==> 2 Nd"
			elif(RecData=="3"):
				ket = RecData + " ==> Extra Time 1 St"
			elif(RecData=="4"):
				ket = RecData + " ==> Extra Time 2 Nd"

			elif(RecData=="k"):
				ket = RecData + " ==> Magenta KickOff"
			elif(RecData=="f"):
				ket = RecData + " ==> Magenta FreeCick"
			elif(RecData=="g"):
				ket = RecData + " ==> Magenta GoalKick"
			elif(RecData=="t"):
				ket = RecData + " ==> Magenta ThrowIn"
			elif(RecData=="c"):
				ket = RecData + " ==> Magenta CornerKick"
			elif(RecData=="p"):
				ket = RecData + " ==> Magenta PenaltyKick"
			elif(RecData=="o"):
				ket = RecData + " ==> Magenta Repair"
			elif(RecData=="a"):
				ket = RecData + " ==> Magenta Goal"
			elif(RecData=="y"):
				ket = RecData + " ==> Magenta YellowCard"
			elif(RecData=="r"):
				ket = RecData + " ==> Magenta RedCard"

			if RecData is None:
				sys.exit(1)
				s.close()

			pub = rospy.Publisher('chatter', String, queue_size=10)
			rospy.init_node('talker',anonymous=True)
			rate = rospy.Rate(10) # 10hz
			if not rospy.is_shutdown():
				hello_str =  RecData
				print "Keadaan Saat Ini : ", ket
				rospy.loginfo(hello_str)
				pub.publish(hello_str)
				# tkMessageBox.showinfo("Publisher Data !! ",ket)
				rate.sleep()

		except Exception as e:			
			s.close()

if __name__ == '__main__':
	master = Tk()
	master.title("ROBSONEMA TEAM")
	master.geometry("300x100+30+30") 
	setIp = Label(master,text="IP Address Referee Box : ")
	setIp.grid(row=0,column=0)
	setIp.pack()
	setIpIsi = Entry(master,bd=5)
	setIpIsi.pack()

	buttonCon = Button(master, text ="Connect", command = callbackButton)
	buttonCon.pack()

	master.mainloop()