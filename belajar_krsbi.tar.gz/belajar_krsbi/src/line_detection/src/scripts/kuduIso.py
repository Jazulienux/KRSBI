import cv2
import numpy as np

def nothing(x):
	pass

cam = cv2.VideoCapture(0)
cam.set(cv2.CAP_PROP_AUTOFOCUS,0)


cv2.namedWindow("Trackbars")

cv2.createTrackbar("L - H","Trackbars",0,179,nothing)
cv2.createTrackbar("L - S","Trackbars",0,255,nothing)
cv2.createTrackbar("L - V","Trackbars",0,255,nothing)
cv2.createTrackbar("U - H","Trackbars",179,179,nothing)
cv2.createTrackbar("U - S","Trackbars",255,255,nothing)
cv2.createTrackbar("U - V","Trackbars",255,255,nothing)

while True:
	_, frame = cam.read()
	frame = cv2.resize(frame,(300,250))

	hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
	
	l_h = cv2.getTrackbarPos("L - H","Trackbars")
	l_s = cv2.getTrackbarPos("L - S","Trackbars")
	l_v = cv2.getTrackbarPos("L - V","Trackbars")
	u_h = cv2.getTrackbarPos("U - H","Trackbars")
	u_s = cv2.getTrackbarPos("U - S","Trackbars")
	u_v = cv2.getTrackbarPos("U - V","Trackbars")

	lower_white = np.array([l_h,l_s,l_v])
	upper_white = np.array([u_h,u_s,u_v])

	mask = cv2.inRange(hsv,lower_white,upper_white)

	_, contours,_ = cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
	
	kernel = np.ones((1,1),np.uint8)

	erosion = cv2.erode(mask,kernel)
	dilation = cv2.dilate(mask,kernel)

	opening = cv2.morphologyEx(mask,cv2.MORPH_OPEN,kernel,iterations =1)
	closing = cv2.morphologyEx(mask,cv2.MORPH_CLOSE,kernel,iterations =1)

	result = cv2.bitwise_and(frame,frame,mask = mask)


	for cnt in contours:
		area = cv2.contourArea(cnt)

		if area > 1000:
			cv2.drawContours(frame,contours,-1,(0,0,0), 3)

	cv2.drawContours(frame,contours,-1,(0,0,0), 3)

	key = cv2.waitKey(1)
	if key == 27:
		break

	
	# cv2.imshow("Frame ",frame)
	cv2.imshow("Mask ",mask)
	cv2.imshow("Result ",result)
	cv2.imshow("Erosion ",erosion)
	cv2.imshow("Dilation ",dilation)
	# cv2.imshow("Opening ",opening)
	# cv2.imshow("Closing ",closing)

cam.release()
cam.destroyAllWindows()
