import cv2
import numpy as np

def nothing(x):
	pass

cam = cv2.VideoCapture(0)
cv2.namedWindow("Trackbars")

cv2.createTrackbar("L - H","Trackbars",0,179,nothing)
cv2.createTrackbar("L - S","Trackbars",0,255,nothing)
cv2.createTrackbar("L - V","Trackbars",0,255,nothing)
cv2.createTrackbar("U - H","Trackbars",179,179,nothing)
cv2.createTrackbar("U - S","Trackbars",255,255,nothing)
cv2.createTrackbar("U - V","Trackbars",255,255,nothing)

font = cv2.FONT_HERSHEY_COMPLEX

while True:
	_, frame = cam.read()
	frame = cv2.resize(frame,(200,175))


	hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

	l_h = cv2.getTrackbarPos("L - H","Trackbars")
	l_s = cv2.getTrackbarPos("L - S","Trackbars")
	l_v = cv2.getTrackbarPos("L - V","Trackbars")
	u_h = cv2.getTrackbarPos("U - H","Trackbars")
	u_s = cv2.getTrackbarPos("U - S","Trackbars")
	u_v = cv2.getTrackbarPos("U - V","Trackbars")

	lower_white = np.array([l_h,l_s,l_v])
	upper_white = np.array([u_h,u_s,u_v])

	mask = cv2.inRange(hsv,lower_white,upper_white)

	kernel = np.ones((5,5),np.uint8)

	erosion = cv2.erode(mask,kernel)
	dilation = cv2.dilate(mask,kernel)

	opening = cv2.morphologyEx(mask,cv2.MORPH_OPEN,kernel,iterations =2)
	closing = cv2.morphologyEx(mask,cv2.MORPH_CLOSE,kernel,iterations =2)

	result = cv2.bitwise_and(frame,frame,mask = mask)

	_, contours,_ = cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

	for cnt in contours:
		area = cv2.contourArea(cnt)
		approx = cv2.approxPolyDP(cnt,0.01*cv2.arcLength(cnt,True),True)
		x = approx.ravel()[0]
		y = approx.ravel()[1]

		if area > 400:
			cv2.drawContours(frame,[approx],0,(0,0,0), 5)
			
		if len(approx) > 10 and len(approx) < 25:
			cv2.putText(frame, "Bola",(x,y),font,1,(0,0,0))

		print len(approx)

	cv2.imshow("Frame ",frame)
	cv2.imshow("Mask ",mask)
	cv2.imshow("Result ",result)
	cv2.imshow("Erosion ",erosion)
	cv2.imshow("Dilation ",dilation)
	cv2.imshow("Opening ",opening)
	cv2.imshow("Closing ",closing)

	key = cv2.waitKey(1)
	if key == 27:
		break

cam.release()
cv2.destroyAllWindows()
