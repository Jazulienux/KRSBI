import cv2
import numpy as np

cap = cv2.VideoCapture(1)
while True:
	ret,img = cap.read()
	cv2.imshow('Video From Camera',img)
	k = cv2.waitKey(10) & 0xff
	if k == 27:
		break
cv2.destroyAllWindows()